# school-code
Project with web page for SchoolCode

Demo page https://fallgamlet.github.io/school-code/
